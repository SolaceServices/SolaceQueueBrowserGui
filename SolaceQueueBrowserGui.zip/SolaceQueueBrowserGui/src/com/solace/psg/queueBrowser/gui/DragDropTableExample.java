package com.solace.psg.queueBrowser.gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

public class DragDropTableExample extends JFrame {

    private Point mousePressPoint;

    public DragDropTableExample() {
        setTitle("Drag and Drop Table Example");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTable table1 = createTable();
        JTable table2 = createTable();

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(table1), new JScrollPane(table2));
        splitPane.setDividerLocation(300);
        add(splitPane);

        table1.setDragEnabled(true);
        table1.setTransferHandler(new IconTransferHandler());

        table2.setDragEnabled(true);
        table2.setTransferHandler(new IconTransferHandler());

        table1.addMouseListener(new TableMouseListener(table1));
        table2.addMouseListener(new TableMouseListener(table2));
    }

    private JTable createTable() {
        DefaultTableModel model = new DefaultTableModel(new Object[]{"Icon", "Name"}, 0);
        JTable table = new JTable(model) {
            @Override
            public Class<?> getColumnClass(int column) {
                return column == 0 ? Icon.class : Object.class;
            }
        };

        model.addRow(new Object[]{new ImageIcon("icon1.png"), "Item 1"});
        model.addRow(new Object[]{new ImageIcon("icon2.png"), "Item 2"});
        model.addRow(new Object[]{new ImageIcon("icon3.png"), "Item 3"});

        return table;
    }

    private class IconTransferHandler extends TransferHandler {
        @Override
        public int getSourceActions(JComponent c) {
            return MOVE;
        }

        @Override
        protected Transferable createTransferable(JComponent c) {
            JTable table = (JTable) c;
            int row = table.getSelectedRow();
            Icon icon = (Icon) table.getValueAt(row, 0);
            return new IconTransferable(icon);
        }

        @Override
        public boolean canImport(TransferSupport support) {
            return support.isDataFlavorSupported(DataFlavor.imageFlavor);
        }

        @Override
        public boolean importData(TransferSupport support) {
            if (!canImport(support)) {
                return false;
            }

            JTable.DropLocation dropLocation = (JTable.DropLocation) support.getDropLocation();
            JTable targetTable = (JTable) support.getComponent();
            int row = dropLocation.getRow();

            try {
                Icon icon = (Icon) support.getTransferable().getTransferData(DataFlavor.imageFlavor);
                targetTable.setValueAt(icon, row, 0);
                System.out.println(row);
                return true;
            } catch (UnsupportedFlavorException | IOException ex) {
                ex.printStackTrace();
            }

            return false;
        }
    }

    private class IconTransferable implements Transferable {
        private final Icon icon;

        public IconTransferable(Icon icon) {
            this.icon = icon;
        }

        @Override
        public DataFlavor[] getTransferDataFlavors() {
            return new DataFlavor[]{DataFlavor.imageFlavor};
        }

        @Override
        public boolean isDataFlavorSupported(DataFlavor flavor) {
            return DataFlavor.imageFlavor.equals(flavor);
        }

        @Override
        public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException {
            if (!isDataFlavorSupported(flavor)) {
                throw new UnsupportedFlavorException(flavor);
            }
            return icon;
        }
    }

    private class TableMouseListener extends MouseAdapter {
        private final JTable table;

        public TableMouseListener(JTable table) {
            this.table = table;
        }

        @Override
        public void mousePressed(MouseEvent e) {
            mousePressPoint = e.getPoint();
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            mousePressPoint = null;
        }

        @Override
        public void mouseDragged(MouseEvent e) {
            if (mousePressPoint != null) {
                Point dragPoint = e.getPoint();
                int dragDistance = (int) mousePressPoint.distance(dragPoint);
                if (dragDistance > 5) { // Threshold distance to start drag
                    TransferHandler handler = table.getTransferHandler();
                    handler.exportAsDrag(table, e, TransferHandler.MOVE);
                }
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            DragDropTableExample example = new DragDropTableExample();
            example.setVisible(true);
        });
    }
}
