package com.solace.psg.queueBrowser.gui;

import javax.swing.*;
import java.awt.*;

public class JListWithIcons {
    public static void main(String[] args) {
        JFrame frame = new JFrame("JList with Icons");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        // Create a model
        DefaultListModel<ListItem> model = new DefaultListModel<>();
        
        model.addElement(new ListItem(" Option 1\thi", new ImageIcon("config/queueSm.png")));
        model.addElement(new ListItem(" Option 2\t hoi", new ImageIcon("config/queueSm.png")));
        model.addElement(new ListItem(" Option 3", new ImageIcon("config/queueSm.png")));

        // Create a JList
        JList<ListItem> list = new JList<>(model);

        // Set custom renderer
        list.setCellRenderer(new ListCellRenderer<ListItem>() {
            @Override
            public Component getListCellRendererComponent(
                JList<? extends ListItem> list,
                ListItem value,
                int index,
                boolean isSelected,
                boolean cellHasFocus
            ) {
                JPanel panel = new JPanel(new BorderLayout());
                JLabel iconLabel = new JLabel(value.getIcon());
                JLabel textLabel = new JLabel(value.getText());
                panel.add(iconLabel, BorderLayout.WEST);
                panel.add(textLabel, BorderLayout.CENTER);

                // Handle selection and focus
                if (isSelected) {
                    panel.setBackground(list.getSelectionBackground());
                    textLabel.setForeground(list.getSelectionForeground());
                } else {
                    panel.setBackground(list.getBackground());
                    textLabel.setForeground(list.getForeground());
                }

                return panel;
            }
        });

        // Add list to the frame
        frame.add(new JScrollPane(list));
        frame.setVisible(true);
    }
}

class ListItem {
    private String text;
    private Icon icon;

    public ListItem(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }

    @Override
    public String toString() {
        return text;
    }
}