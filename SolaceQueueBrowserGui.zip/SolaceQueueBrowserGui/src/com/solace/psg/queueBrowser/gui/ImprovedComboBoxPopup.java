package com.solace.psg.queueBrowser.gui;
import javax.swing.*;
import java.awt.*;

public class ImprovedComboBoxPopup {

    public static void main(String[] args) {
        JFrame parentFrame = new JFrame("Parent Frame");
        parentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        parentFrame.setSize(400, 300);
        parentFrame.setLayout(new FlowLayout());
        
        JButton showPopupButton = new JButton("Show Popup");
        parentFrame.add(showPopupButton);
        parentFrame.setVisible(true);
        
        showPopupButton.addActionListener(e -> showPopup(parentFrame));
    }

    private static void showPopup(JFrame parentFrame) {
        // Create a JDialog
        JDialog dialog = new JDialog(parentFrame, "Select an Option", true);
        dialog.setSize(350, 200);
        dialog.setLayout(new BorderLayout());
        
        // Add a label with instructions (left-aligned)
        JLabel instructionLabel = new JLabel("Please select an option from the list below:");
        instructionLabel.setHorizontalAlignment(SwingConstants.LEFT); // Left-aligned
        instructionLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Add space around it
        dialog.add(instructionLabel, BorderLayout.NORTH);

        // Create a JPanel to center the combo box with padding
        JPanel comboPanel = new JPanel(new FlowLayout(FlowLayout.CENTER)); // Centered layout
        comboPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Add space around the combo box
        String[] options = {"Option 1", "Option 2", "Option 3", "Option 4"};
        JComboBox<String> comboBox = new JComboBox<>(options);
        comboPanel.add(comboBox);
        dialog.add(comboPanel, BorderLayout.CENTER);

        // Create a JPanel for the OK button (right-aligned)
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT)); // Right-aligned layout
        JButton okButton = new JButton("OK");
        buttonPanel.add(okButton);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        // Listener for the OK button
        okButton.addActionListener(e -> {
            String selectedOption = (String) comboBox.getSelectedItem();
            System.out.println("Selected Option: " + selectedOption);
            dialog.dispose(); // Close the dialog
        });

        // Center the dialog relative to the parent and make it visible
        dialog.setLocationRelativeTo(parentFrame);
        dialog.setVisible(true);
    }
}