package com.solace.psg.queueBrowser.gui;
import javax.swing.*;
import java.awt.*;

public class IconAnimation extends JPanel {
    private int shovelX = 5; // Starting X position for the shovel
    private int shovelY = 100; // Y position for the shovel
    private int shovelDX = 1; // Shovel's horizontal movement speed

    private int flyingX = shovelX + 50; // Starting position for flying object
    private int flyingY = shovelY - 20; // Y position for the flying object

    private final ImageIcon shovelIcon;
    private final ImageIcon flyingIcon;

    public IconAnimation() {
        // Load your icons (replace "shovel.png" and "flyingObject.png" with your image paths)
        shovelIcon = new ImageIcon("config/shovel.png");
        flyingIcon = new ImageIcon("config/messageIcon32.png");

        // Timer to animate the objects
        Timer shovelTimer = new Timer(100, e -> {
            // Move the shovel back and forth
            shovelX += shovelDX;
            if (shovelX < 5 || shovelX > 30) {
            	System.out.println("Switching " + shovelX);
                shovelDX = -shovelDX;
            }

            // Move the flying object across the screen
            flyingX += 10; // Constant speed to the right
            if (flyingX > getWidth()) {
                flyingX = shovelX + 50; // Reset flying object near the shovel
            }

            repaint(); // Update the screen
        });
        shovelTimer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Draw the shovel icon
        shovelIcon.paintIcon(this, g, shovelX, shovelY);

        // Draw the flying object icon
        flyingIcon.paintIcon(this, g, flyingX, flyingY);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Icon Animation");
        IconAnimation animation = new IconAnimation();
        frame.add(animation, BorderLayout.NORTH);
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout()); // Use BorderLayout


        JProgressBar progressBar = new JProgressBar();
        progressBar.setMinimum(0);
        progressBar.setMaximum(100);
        progressBar.setStringPainted(true); // Display percentage text
        progressBar.setPreferredSize(new Dimension(frame.getWidth(), 30)); // Set fixed height

        // Add the progress bar to the bottom of the frame
        frame.add(progressBar, BorderLayout.SOUTH); // Pin to bottom

        // Add the progress bar to the frame
        frame.add(progressBar, BorderLayout.CENTER);

        
        frame.setVisible(true);
    }
}